# Coast Demo

A Node.js app with Postgres and Redis for testing coast's multi-instance workflow.

## Prerequisites

- Docker running
- Coast built from source (`cargo build --workspace` in the parent coast repo)
- `socat` installed (`brew install socat` on macOS)

## Quick start

```bash
# 1. Run setup (creates git repo + feature branches)
cd ..  # integrated_examples/
./setup.sh

# 2. Build coast binaries
cd ../  # coast repo root
cargo build --workspace
export PATH="$(pwd)/target/debug:$PATH"

# 3. Start daemon and build
coastd --foreground &
cd integrated_examples/coast-demo
coast build

# 4. Run instances
coast run main
coast run feature-greeting --branch feature-greeting

# 5. Test checkout swap
coast checkout main
curl http://localhost:33000/          # "Hello from Coast!"

coast checkout feature-greeting
curl http://localhost:33000/          # "Hello from Feature Branch!"
```

## Ports

| Service  | Canonical Port | Internal Port |
|----------|---------------|---------------|
| app      | 33000         | 3000          |
| postgres | 35432         | 5432          |
| redis    | 36379         | 6379          |

## What this tests

- `coast build` parses Coastfile and caches OCI images
- `coast run` creates DinD containers with published ports
- `coast run --branch` creates git worktrees with branch-specific code
- `coast checkout` swaps canonical ports instantly via socat
- `coast stop` / `coast start` preserves state across restarts
- `coast rm` cleans up containers and port allocations

## The app

Simple hit counter: each request increments counters in both Postgres and Redis.

```bash
curl http://localhost:33000/
# {"message":"Hello from Coast!","path":"/","redis_hits":1,"postgres_hits":"1"}

curl http://localhost:33000/health
# {"status":"ok"}
```

Each coast instance gets isolated Postgres and Redis, so hit counts are independent.
