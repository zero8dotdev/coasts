const http = require("http");

const PORT = 48090;
const HOST_API = process.env.HOST_API_URL || "http://host.docker.internal:48080";

const server = http.createServer(async (req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok", source: "coast-egress" }));
    return;
  }

  if (req.url === "/egress") {
    try {
      const upstream = await fetch(`${HOST_API}/health`);
      const body = await upstream.text();
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(body);
    } catch (err) {
      res.writeHead(502, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  res.writeHead(404);
  res.end("not found");
});

server.listen(PORT, () => {
  console.log(`coast-egress app listening on port ${PORT}`);
});
