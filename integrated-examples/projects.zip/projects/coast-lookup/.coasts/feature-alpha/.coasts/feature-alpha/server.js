const http = require("http");

const server = http.createServer((req, res) => {
  const json = (data) => {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  if (req.url === "/health") return json({ status: "ok" });
  return json({ service: "coast-lookup", branch: "feature-alpha" });
});

server.listen(3000, () => console.log("Lookup test server on :3000"));
