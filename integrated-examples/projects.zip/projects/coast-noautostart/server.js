const http = require('http');
const PORT = 40100;
const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok' }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Hello from coast-noautostart');
});
server.listen(PORT, () => console.log(`Listening on ${PORT}`));
