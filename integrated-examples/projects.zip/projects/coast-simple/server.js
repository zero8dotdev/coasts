const http = require("http");
const os = require("os");

const PORT = process.env.PORT || 40000;

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(
    JSON.stringify({
      message: "Hello from Coast!",
      hostname: os.hostname(),
      platform: os.platform(),
      uptime: process.uptime(),
    })
  );
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
