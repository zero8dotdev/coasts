const http = require("http");
const { Pool } = require("pg");

const PORT = 3000;

const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });

async function ensureTable() {
  await pgPool.query(`
    CREATE TABLE IF NOT EXISTS vol_test (
      id SERIAL PRIMARY KEY,
      label TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
}

async function init() {
  await ensureTable();
  console.log("Connected to Postgres.");
}

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({ status: "ok" });
    }

    if (req.url === "/db-check") {
      const r = await pgPool.query("SELECT current_user AS user, current_database() AS db");
      return json({ db: "connected", user: r.rows[0].user, database: r.rows[0].db });
    }

    if (req.url === "/db-write") {
      await ensureTable();
      const label = `entry-${Date.now()}`;
      const r = await pgPool.query(
        "INSERT INTO vol_test (label) VALUES ($1) RETURNING *",
        [label]
      );
      return json({ written: r.rows[0] }, 201);
    }

    if (req.url === "/db-read") {
      const r = await pgPool.query("SELECT * FROM vol_test ORDER BY id");
      return json({ rows: r.rows, count: r.rows.length });
    }

    return json({ message: "host-shared-services-volume test app" });
  } catch (err) {
    console.error("Request error:", err);
    json({ error: err.message }, 500);
  }
});

init()
  .then(() => {
    server.listen(PORT, () => console.log(`Listening on :${PORT}`));
  })
  .catch((err) => {
    console.error("Failed to start:", err);
    process.exit(1);
  });
